# 함수정의(만든다)
def add(n1, n2):
    print(n1 + n2)

def minus(n1, n2):
    # pass
    print(n1 - n2)

# 곱하기 함수
def mul(n1, n2):
    print(n1 * n2)
    
# 나누기 함수
def div(n1, n2):
    print(n1 / n2)
    
# 함수사용(호출), 여러번 호출 가능

add(100, 200)
minus(100, 200)
mul(100, 200)
div(100, 200)





