# 함수정의(만든다)
def add():
    print('더하기 연산 수행')

def minus():
    # pass
    print('빼기 연산 수행')

# 곱하기 함수
def mul():
    print('곱하기 연산 수행')
    
# 나누기 함수
def div():
    print('나누기 연산 수행')
    
# 함수사용(호출), 여러번 호출 가능
add()
add()
minus()
mul()
div()



