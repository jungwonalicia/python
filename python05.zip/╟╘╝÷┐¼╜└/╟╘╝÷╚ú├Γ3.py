# 함수정의(만든다)
def add(n1, n2):
    print(n1 + n2)
def minus(n1, n2):
    # pass
    print(n1 - n2)

# 곱하기 함수
def mul(n1, n2):
    print(n1 * n2)
    
# 나누기 함수
def div(n1, n2):
    print(n1 / n2)
    
# 함수사용(호출), 여러번 호출 가능

x = int(input("숫자1 입력>> "))
y = int(input("숫자2 입력>> "))

add(x, y)
minus(x, y)
mul(x, y)
div(x, y)





