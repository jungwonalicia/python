
name = input("이름을  입력하세요. >> ")

성씨 = name[0]

if  성씨 == '김':
    print("김씨 성이시군요.")
elif 성씨 == '박':
    print("박씨 성이시군요.")
elif 성씨 == '홍':
    print("홍씨 성이시군요.")
else:
    print("다른 성씨를 가지셨군요.")
    
     