# String은 char를 실로 묶어놓은 것처럼 쭉 연결해놓은 것.
name = '홍길동'

print(name[0])
print(name[1])
print(name[2])
print()

for i in range(0, 3, 1):
    print(name[i])

