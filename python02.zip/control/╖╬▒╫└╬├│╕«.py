id = "root"
pw = "1234"

data1 = input("ID입력 : ")
data2 = input("PW입력 : ")

#저장(컨트롤+s), 실행(컨트롤+F11)
if id == data1 and pw == data2:
    print("로그인 OK")
else :
    print("로그인 NOT")


