# 파이썬의 반복문: while, for
# for문 : 횟수를 지정할 수 있다.

for x in [1, 2, 3] :
    print(x, " ★")
    
print()

for x in range(1, 6):
    print(x, " ★")

print()

for x in range(1, 1001):
    print(x, " ★")  
    
print()

for x in range(1, 11) :
    print("★", end="")
    
print()    
for x in range(0, 10) :
    print("★", end="")










