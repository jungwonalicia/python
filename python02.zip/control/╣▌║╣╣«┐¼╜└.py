# while 조건 :
#     반복할 처리 내용.

# 무한루프..
while True :
    data = input("종료하실건가요?? 종료)x입력  ")
    if data == 'x' :
        print("프로그램을 종료합니다.")
        break
    print("내가 계속 반복됩니다..")
