food = input("뭐 먹고 싶니?? 자장면, 김밥, 회 중에서 골라요.")

if food == '자장면':
    print("중국집으로 가요..")
elif food == '김밥':
    print("분식집으로 가요..")
elif food == '회':
    print("횟집으로 가요..")
else :
    print("그냥 집에서 먹어요..")



