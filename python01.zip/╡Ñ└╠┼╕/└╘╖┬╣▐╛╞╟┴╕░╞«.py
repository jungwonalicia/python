name = "슛" #문자열
ystart = 200 #숫자(정수)
movevalue = -10.5 #숫자(실수)

#데이타가 들어가는 공간 = 변수
print("미사일은 이름은 " , name)
print("미사일 시작값은 ", ystart, "미터")
print("미사일 움직이는 값은 " , movevalue, "입니다.")

