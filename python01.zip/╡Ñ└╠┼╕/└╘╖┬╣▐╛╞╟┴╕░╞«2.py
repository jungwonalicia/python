# 설명을 쓰고 사용 => comment(주석)
# 1) 콘솔에서 키보드로 넣은 값을 변수에 저장
# 2) 저장한 변수의 값을 프린트

name = input("당신의 이름을 입력하세요. ")
print("입력받은 값은 ", name)
print()
age = input("당신의 나이는 ")
print("입력받은 값은 ", age)










