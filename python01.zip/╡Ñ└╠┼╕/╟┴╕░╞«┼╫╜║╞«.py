print("헬로 월드...")
print("나의 이름은 파이썬")
print("나는 학생입니다.")
print()
print("나는 ", end=" ")
print("파이썬 프로그래머", end=" ")
print("입니다.")
print()
print("나는 ", end="★")



