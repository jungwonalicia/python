year = int(input("태어난 해를 입력하세요."))

age = 2019 - year + 1

print("당신의 나이는 ", age, "살입니다.")

if age >= 18 : #콜론
    print("성인입니다.")
else:
    print("성인이 아닙니다.")