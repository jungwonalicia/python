file1 = open('test1.txt', 'w') #w=write(쓸 수 있음)
file1.write('안녕...\n')
file1.write('또 만났네요...\n')
file1.write('안녕히가세요....\n')