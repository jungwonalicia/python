file4 = open('tv.txt', 'r')

data = file4.readline()
print(data)

data2 = file4.readline()
print(data2)