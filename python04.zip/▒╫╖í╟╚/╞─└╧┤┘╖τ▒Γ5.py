file4 = open('tv.txt', 'r')

for count in range(0, 10):
    data = file4.read()
    print(data)

