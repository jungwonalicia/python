file2 = open('test2.txt', 'w')
data = input("파일에 저장할 내용 입력1: ")
file2.write(data + '\n')
data2 = input("파일에 저장할 내용 입력2: ")
file2.write(data2 + '\n')

